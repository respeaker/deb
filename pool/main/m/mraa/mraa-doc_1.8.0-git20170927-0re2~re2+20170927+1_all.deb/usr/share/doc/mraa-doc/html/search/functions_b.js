var searchData=
[
  ['oniioevent',['onIioEvent',['../classmraa_1_1_iio_handler.html#a986d3b4fcfaa471893b87d298b6d56d7',1,'mraa::IioHandler']]],
  ['outputmode',['outputMode',['../classmraa_1_1_gpio.html#a5b651421d230ba266c24bc6437b27c2c',1,'mraa::Gpio']]]
];
