var searchData=
[
  ['dataavailable',['dataAvailable',['../classmraa_1_1_uart.html#a81357f04a949c0557227193d66ebb8d5',1,'mraa::Uart']]],
  ['de_5fnano_5fsoc',['DE_NANO_SOC',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9ac2fc91fbe48ce1c5c13514888a3ba4b0',1,'mraa']]],
  ['debugging_20libmraa',['Debugging libmraa',['../debugging.html',1,'']]],
  ['diff',['diff',['../structmraa_1_1_iio_event_data.html#a65f3a8178e1f997a7a19a988bb0f4e1a',1,'mraa::IioEventData']]],
  ['dir',['dir',['../classmraa_1_1_gpio.html#a054bbac021151c0f951ea75d2ee908de',1,'mraa::Gpio::dir()'],['../namespacemraa.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4',1,'mraa::Dir()']]],
  ['dir_5fin',['DIR_IN',['../namespacemraa.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4a79cfda2208c6d7f29cc8f756de35d9f1',1,'mraa']]],
  ['dir_5fout',['DIR_OUT',['../namespacemraa.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4ac7981dbdf851784e61f1dfb7abb53af7',1,'mraa']]],
  ['dir_5fout_5fhigh',['DIR_OUT_HIGH',['../namespacemraa.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4a6bef5463c450d62cc369152a51a9784b',1,'mraa']]],
  ['dir_5fout_5flow',['DIR_OUT_LOW',['../namespacemraa.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aa08553291d3c6bd2d914c46ccfd79cc9',1,'mraa']]],
  ['direction',['direction',['../structmraa_1_1_iio_event_data.html#a886d551d5381dc3e53f17825ffc51641',1,'mraa::IioEventData']]]
];
