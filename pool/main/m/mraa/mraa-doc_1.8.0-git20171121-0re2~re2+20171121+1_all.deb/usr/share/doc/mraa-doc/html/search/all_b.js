var searchData=
[
  ['json_20platform',['JSON platform',['../jsonplat.html',1,'']]]
];
