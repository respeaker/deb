var searchData=
[
  ['mask',['mask',['../structmraa__iio__channel.html#a6f26bbb3e63b096143b8024debecedf9',1,'mraa_iio_channel']]],
  ['modifier',['modifier',['../structmraa_1_1_iio_event_data.html#a75316f8e4ed23559b01079c4af92cb68',1,'mraa::IioEventData']]]
];
