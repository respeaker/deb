var searchData=
[
  ['raspberry_5fpi',['RASPBERRY_PI',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a66191e2b07ffb64166e871af4d5f572b',1,'mraa']]],
  ['raspberrywiring',['RaspberryWiring',['../namespacemraa.html#afbb5def853f0e41f65de26bfd5567563',1,'mraa']]],
  ['raspberry_20pi',['Raspberry Pi',['../rasppi.html',1,'']]],
  ['read',['read',['../classmraa_1_1_aio.html#a64d51a57fcf17bd9425c03af6c3c0bfc',1,'mraa::Aio::read()'],['../classmraa_1_1_gpio.html#aaab5dab5b969a87f538242e524431637',1,'mraa::Gpio::read()'],['../classmraa_1_1_i2c.html#a7c0088145d3ffdbe946b0f216dccbaf5',1,'mraa::I2c::read()'],['../classmraa_1_1_pwm.html#a868d9d1513fbaf34c4d5d15a7fa4baa8',1,'mraa::Pwm::read()'],['../classmraa_1_1_uart.html#a161ea43dffd2c0f39a36a1fee6ba336d',1,'mraa::Uart::read()']]],
  ['readbrightness',['readBrightness',['../classmraa_1_1_led.html#a46943382dcbb65e92167a4cc113bbde6',1,'mraa::Led']]],
  ['readbyte',['readByte',['../classmraa_1_1_i2c.html#a9b760904bbc60f357339dc98253d6d17',1,'mraa::I2c::readByte()'],['../classmraa_1_1_uart_o_w.html#a9b760904bbc60f357339dc98253d6d17',1,'mraa::UartOW::readByte()']]],
  ['readbytesreg',['readBytesReg',['../classmraa_1_1_i2c.html#a811fabe49072ede2144d3118b5b8ba8f',1,'mraa::I2c']]],
  ['readdir',['readDir',['../classmraa_1_1_gpio.html#a1785e69d7763ccb71406393716f3473c',1,'mraa::Gpio']]],
  ['readfloat',['readFloat',['../classmraa_1_1_aio.html#aa5de12b8cd82d61b545a85ea991944a3',1,'mraa::Aio::readFloat()'],['../classmraa_1_1_iio.html#a8b4b8e4322bdf91c8773d76306d6a03f',1,'mraa::Iio::readFloat()']]],
  ['readint',['readInt',['../classmraa_1_1_iio.html#a9f72ab4a59c9ba12154987746c2169bc',1,'mraa::Iio']]],
  ['readmaxbrightness',['readMaxBrightness',['../classmraa_1_1_led.html#af06bcc063254cd37791624316de1c25f',1,'mraa::Led']]],
  ['readreg',['readReg',['../classmraa_1_1_i2c.html#a2e9db5636b09511a0663c21aab12a20d',1,'mraa::I2c']]],
  ['readstr',['readStr',['../classmraa_1_1_uart.html#a897506bdfe62d81a69aedfd29108257b',1,'mraa::Uart']]],
  ['readwordreg',['readWordReg',['../classmraa_1_1_i2c.html#a72d89b8eb15fa2d963430437c31c473b',1,'mraa::I2c']]],
  ['registereventhandler',['registerEventHandler',['../classmraa_1_1_iio.html#a3eb3c5401274eac453dd83aff3bf0c10',1,'mraa::Iio']]],
  ['removesubplatform',['removeSubplatform',['../namespacemraa.html#a3832db6f2d5c973cd69bafb2fa0aa7e8',1,'mraa']]],
  ['reset',['reset',['../classmraa_1_1_uart_o_w.html#ae95e1875c88c35f003672ca58fcd4571',1,'mraa::UartOW']]],
  ['result',['Result',['../namespacemraa.html#a28287671eaf7406afd604bd055ba4066',1,'mraa']]],
  ['rom_5fno',['ROM_NO',['../struct__mraa__uart__ow.html#ac614683cd6f2cb8d09fe21515d75718d',1,'_mraa_uart_ow']]]
];
