var searchData=
[
  ['search',['search',['../classmraa_1_1_uart_o_w.html#a30cdf21f63946e15de55341d5cc848e2',1,'mraa::UartOW::search(bool start, uint8_t *id)'],['../classmraa_1_1_uart_o_w.html#aee6629cd16c56da904abf001832347d5',1,'mraa::UartOW::search(bool start)']]],
  ['sendbreak',['sendBreak',['../classmraa_1_1_uart.html#ae0a202a26724dcfa65b3c34d85dab3a6',1,'mraa::Uart']]],
  ['setbaudrate',['setBaudRate',['../classmraa_1_1_uart.html#a362e4c29f0ff05f19fd6e20f16371063',1,'mraa::Uart']]],
  ['setbit',['setBit',['../classmraa_1_1_aio.html#a0abf8357da5d76d3a7d26c821a20ee89',1,'mraa::Aio']]],
  ['setflowcontrol',['setFlowcontrol',['../classmraa_1_1_uart.html#a08a2bfd56f4704a2ed27d122181e28ef',1,'mraa::Uart']]],
  ['setloglevel',['setLogLevel',['../namespacemraa.html#a48330ac0fe188763ad17f4d18e2874ee',1,'mraa']]],
  ['setmode',['setMode',['../classmraa_1_1_uart.html#aa124e631cde40fc83fe0340b253c6f4b',1,'mraa::Uart']]],
  ['setnonblocking',['setNonBlocking',['../classmraa_1_1_uart.html#a8b64a46d2fa4004180a9c4d33b29d08d',1,'mraa::Uart']]],
  ['setpriority',['setPriority',['../namespacemraa.html#addc61d842c51f5a7f22bc3d165b9ba29',1,'mraa']]],
  ['settimeout',['setTimeout',['../classmraa_1_1_uart.html#abfc7264a4ef49271b2b1093feef3d31a',1,'mraa::Uart']]],
  ['spi',['Spi',['../classmraa_1_1_spi.html#a5c14b959d8147f987b1fca7f1a9ccfe7',1,'mraa::Spi::Spi(int bus)'],['../classmraa_1_1_spi.html#a77ff483ea0b1f56531eff78317d9f74f',1,'mraa::Spi::Spi(int bus, int cs)'],['../classmraa_1_1_spi.html#aeca68f782c40a53ea837b8e2d06a7850',1,'mraa::Spi::Spi(void *spi_context)']]]
];
