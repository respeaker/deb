var searchData=
[
  ['lsbmode',['lsbmode',['../classmraa_1_1_spi.html#aade8031ed52e9a2181829198cee0b9c6',1,'mraa::Spi']]]
];
