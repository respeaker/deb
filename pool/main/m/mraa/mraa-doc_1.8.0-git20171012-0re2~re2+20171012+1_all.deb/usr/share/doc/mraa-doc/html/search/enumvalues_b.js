var searchData=
[
  ['unknown_5fplatform',['UNKNOWN_PLATFORM',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a8e0da7a705cf9d08ebffe49c0c8441d9',1,'mraa']]]
];
