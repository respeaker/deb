var searchData=
[
  ['lastdeviceflag',['LastDeviceFlag',['../struct__mraa__uart__ow.html#a3522364b905008129fa78f7cd1792dac',1,'_mraa_uart_ow']]],
  ['lastdiscrepancy',['LastDiscrepancy',['../struct__mraa__uart__ow.html#ac3990e2ccef4f910a2218efddbfe2484',1,'_mraa_uart_ow']]],
  ['lastfamilydiscrepancy',['LastFamilyDiscrepancy',['../struct__mraa__uart__ow.html#a06292b1b524cfd36e77c91b979b47a3e',1,'_mraa_uart_ow']]],
  ['lendian',['lendian',['../structmraa__iio__channel.html#a2a04c6bb0877620b9647eeb3303b0c36',1,'mraa_iio_channel']]],
  ['location',['location',['../structmraa__iio__channel.html#a9919c7e3c12b97030671b4ae84a28c2e',1,'mraa_iio_channel']]]
];
