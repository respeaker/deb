var searchData=
[
  ['bitperword',['bitPerWord',['../classmraa_1_1_spi.html#a173e99a6dd432444fbdf6cb650c102fb',1,'mraa::Spi']]]
];
