var searchData=
[
  ['channel',['channel',['../structmraa_1_1_iio_event_data.html#adf7dff2c57c0da9a4a2b70e3e815be31',1,'mraa::IioEventData']]],
  ['channel2',['channel2',['../structmraa_1_1_iio_event_data.html#a556fbbd314f244452213081bd57ef067',1,'mraa::IioEventData']]],
  ['channeltype',['channelType',['../structmraa_1_1_iio_event_data.html#ace71eb2c5fd1fa79b9c055024bc276d4',1,'mraa::IioEventData']]]
];
