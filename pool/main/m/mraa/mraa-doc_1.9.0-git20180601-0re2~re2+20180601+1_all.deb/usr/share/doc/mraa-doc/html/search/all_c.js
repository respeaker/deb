var searchData=
[
  ['libmraa_20_2d_20low_20level_20skeleton_20library_20for_20communication_20on_20gnu_2flinux_20platforms',['libmraa - Low Level Skeleton Library for Communication on GNU/Linux platforms',['../index.html',1,'']]],
  ['libmraa_20internals',['libmraa Internals',['../internals.html',1,'']]],
  ['lastdeviceflag',['LastDeviceFlag',['../struct__mraa__uart__ow.html#a3522364b905008129fa78f7cd1792dac',1,'_mraa_uart_ow']]],
  ['lastdiscrepancy',['LastDiscrepancy',['../struct__mraa__uart__ow.html#ac3990e2ccef4f910a2218efddbfe2484',1,'_mraa_uart_ow']]],
  ['lastfamilydiscrepancy',['LastFamilyDiscrepancy',['../struct__mraa__uart__ow.html#a06292b1b524cfd36e77c91b979b47a3e',1,'_mraa_uart_ow']]],
  ['led',['Led',['../classmraa_1_1_led.html',1,'Led'],['../classmraa_1_1_led.html#ad14bf65a51db7161d7dceff1686c19da',1,'mraa::Led::Led(const char *led)'],['../classmraa_1_1_led.html#aee2674bd267ada32d2ab3069cd5c41c2',1,'mraa::Led::Led(void *led_context)']]],
  ['led_2eh',['led.h',['../led_8h.html',1,'']]],
  ['lendian',['lendian',['../structmraa__iio__channel.html#a2a04c6bb0877620b9647eeb3303b0c36',1,'mraa_iio_channel']]],
  ['linkit_20smart_207688',['Linkit Smart 7688',['../linkit_7688.html',1,'']]],
  ['location',['location',['../structmraa__iio__channel.html#a9919c7e3c12b97030671b4ae84a28c2e',1,'mraa_iio_channel']]],
  ['lsbmode',['lsbmode',['../classmraa_1_1_spi.html#aade8031ed52e9a2181829198cee0b9c6',1,'mraa::Spi']]]
];
