var searchData=
[
  ['a96boards',['A96BOARDS',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a4c0dc4b74dfc5f87a86e2788f269b070',1,'mraa']]],
  ['android_5fperipheralmanager',['ANDROID_PERIPHERALMANAGER',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a6cd29b26c99299f7dfa6e7698d098cfc',1,'mraa']]]
];
