var searchData=
[
  ['flush',['flush',['../classmraa_1_1_uart.html#aa18c7a06e1aabd29c5e987caedd62ba6',1,'mraa::Uart']]],
  ['frequency',['frequency',['../classmraa_1_1_i2c.html#ab18645c6d509faab73e52dd612f204b0',1,'mraa::I2c::frequency()'],['../classmraa_1_1_spi.html#a59b69e81d8e94611d22f8187ca8c5482',1,'mraa::Spi::frequency()']]]
];
