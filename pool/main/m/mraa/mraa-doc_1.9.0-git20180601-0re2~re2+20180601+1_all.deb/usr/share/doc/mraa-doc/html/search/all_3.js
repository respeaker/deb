var searchData=
[
  ['banana',['BANANA',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9adfb0867c3e2d1ac58389aea3b70af5b7',1,'mraa']]],
  ['banana_20pi_2fpro',['Banana Pi/Pro',['../bananapi.html',1,'']]],
  ['beaglebone',['BEAGLEBONE',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a7d03756958db2349da3dd724169a1a3f',1,'mraa::BEAGLEBONE()'],['../beaglebone.html',1,'(Global Namespace)']]],
  ['bitperword',['bitPerWord',['../classmraa_1_1_spi.html#a173e99a6dd432444fbdf6cb650c102fb',1,'mraa::Spi']]],
  ['bits_5fused',['bits_used',['../structmraa__iio__channel.html#a9c67a09cb5ae030c254f2582bc476f3c',1,'mraa_iio_channel']]],
  ['building_20libmraa',['Building libmraa',['../building.html',1,'']]],
  ['building_20mraa_20with_20imraa',['Building mraa with imraa',['../buildingimraa.html',1,'']]],
  ['bytes',['bytes',['../structmraa__iio__channel.html#a1169e7a0ccc997c70b4d09a87bfc4eec',1,'mraa_iio_channel']]]
];
