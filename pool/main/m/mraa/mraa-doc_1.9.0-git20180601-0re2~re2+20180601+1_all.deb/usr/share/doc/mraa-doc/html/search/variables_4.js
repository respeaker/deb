var searchData=
[
  ['id',['id',['../structmraa__gpio__event.html#a7441ef0865bcb3db9b8064dd7375c1ea',1,'mraa_gpio_event::id()'],['../structiio__event__data.html#a669cc295873b0440d2e3ff9c5a40c36e',1,'iio_event_data::id()']]],
  ['index',['index',['../structmraa__iio__channel.html#a750b5d744c39a06bfb13e6eb010e35d0',1,'mraa_iio_channel']]]
];
