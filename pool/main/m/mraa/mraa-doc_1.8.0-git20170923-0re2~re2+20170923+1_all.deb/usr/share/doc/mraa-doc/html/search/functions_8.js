var searchData=
[
  ['i2c',['I2c',['../classmraa_1_1_i2c.html#ab3124d0211ddd56435494fc1f98aa066',1,'mraa::I2c::I2c(int bus, bool raw=false)'],['../classmraa_1_1_i2c.html#ad58c52e74294febd236060f599d04672',1,'mraa::I2c::I2c(void *i2c_context)']]],
  ['iio',['Iio',['../classmraa_1_1_iio.html#a5bf8807eb9bb24115984a592d140f37a',1,'mraa::Iio::Iio(int device)'],['../classmraa_1_1_iio.html#a13ea9eceacabf1cfac9950b14612087f',1,'mraa::Iio::Iio(const std::string &amp;deviceName)']]],
  ['init',['init',['../namespacemraa.html#ad97236ce7560a2158b2e1ae2d8982a38',1,'mraa']]],
  ['initio',['initIo',['../namespacemraa.html#a96a8111bfc8c3054735f6a48e52f7f3f',1,'mraa']]],
  ['initjsonplatform',['initJsonPlatform',['../namespacemraa.html#a32bc09b0d09501983f3d509cdb55f2ac',1,'mraa']]],
  ['inputmode',['inputMode',['../classmraa_1_1_gpio.html#a8550b31eecf48aeda0e7bece6575cced',1,'mraa::Gpio']]],
  ['isr',['isr',['../classmraa_1_1_gpio.html#af707bfa00ada96a99024e5b0d38a8633',1,'mraa::Gpio']]],
  ['isrexit',['isrExit',['../classmraa_1_1_gpio.html#a6be5bb873bb372fec5c5e3699cd8e6f8',1,'mraa::Gpio']]],
  ['issubplatformid',['isSubPlatformId',['../namespacemraa.html#a5db0c9affe342921a666a98bce08e6d7',1,'mraa']]]
];
