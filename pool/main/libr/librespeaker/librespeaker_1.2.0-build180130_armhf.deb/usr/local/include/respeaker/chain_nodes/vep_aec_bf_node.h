/*
 * Copyright (c) 2017 Seeed Technology Co., Ltd.
 *
 * @author Jack Shao <jacky.shaoxg@gmail.com>
 *
 */



#ifndef __VEP_AEC_BF_NODE_H__
#define __VEP_AEC_BF_NODE_H__

#include "chain_nodes/base_node.h"

namespace respeaker
{

#define FRAME_CNT_PER_BLOCK    128      //8ms for 16k
#define NUM_OF_MICROPHONES     6
#define NUM_OF_BEAMS           7

class VepAecBeamformingNode : public BaseNode
{
public:
    /**
     * @param ref_channel_index - Please note that the channel index starts from `0`. For ReSpeaker v2, it's better to
     *                          specify `6` here.
     *
     * @return VepAecBeamformingNode*
     */
    static VepAecBeamformingNode* Create(int ref_channel_index);
    static VepAecBeamformingNode* Create(int ref_channel_index, bool enable_wav_log);

    virtual ~VepAecBeamformingNode() = default;

    virtual bool OnStartThread() = 0;
    virtual std::string ProcessBlock(std::string block, bool &exit) = 0;
    virtual bool OnJoinThread() = 0;

};

}  //namespace

#endif
