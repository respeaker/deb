/*
 * Copyright (c) 2017 Seeed Technology Co., Ltd.
 *
 * @author Jack Shao <jacky.shaoxg@gmail.com>
 *
 */


#ifndef __DIRECTION_REPORTER_NODE_H__
#define __DIRECTION_REPORTER_NODE_H__

namespace respeaker
{
/**
 * Nodes who can do DoA should inherit from this class.
 */
class DirectionReporterNode
{
public:
    /**
     * Subclass should implement this method.
     */
    // virtual int GetDirection() = 0;
    virtual int GetDirection() = 0;
    virtual void SetDirection(int dir) = 0;
};

}  //namespace

#endif // !__DIRECTION_REPORTER_NODE_H__