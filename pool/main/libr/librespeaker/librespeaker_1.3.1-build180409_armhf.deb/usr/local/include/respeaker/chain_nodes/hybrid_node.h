/*
 * Copyright (c) 2017 Seeed Technology Co., Ltd.
 *
 * @author Jack Shao <jacky.shaoxg@gmail.com>
 *
 */



#ifndef __HYBRID_NODE_H__
#define __HYBRID_NODE_H__

#include "chain_nodes/base_node.h"

namespace respeaker
{
/**
 * The HybirdNode can do the following:
 * - Noise suppresstion
 * - Automatic gain control
 * - Voice available detection
 *
 */
class HybridNode : public BaseNode
{
public:
    /**
     * The description of the `level`s , please see the comments of Create*Only methods.
     */
    static HybridNode* Create(bool enable_ns, int ns_level,
                              bool enable_agc, int agc_level,
                              bool enable_vad, int vad_sensitivity);

    /**
     * @param ns_level - [0, 3], the higher the more noise suppression
     */
    static HybridNode* CreateNsOnly(int ns_level=0);

    /**
     * @param agc_level - [0, 31], Sets the target peak |level| (or envelope) of the AGC in dBFs (decibels
     *                             from digital full-scale). The convention is to use positive values. For
     *                             instance, passing in a value of 3 corresponds to -3 dBFs, or a target
     *                             level 3 dB below full-scale.
     */
    static HybridNode* CreateAgcOnly(int agc_level=3);

    /**
     * @param vad_sesitivity - [0, 3] the higher the more sensitive(more noise being detected as voice)
     */
    static HybridNode* CreateVadOnly(int vad_sensitivity=0);

    virtual ~HybridNode() = default;

    virtual bool OnStartThread() = 0;
    virtual std::string ProcessBlock(std::string block, bool& exit) = 0;
    virtual bool OnJoinThread() = 0;

};

}  //namespace

#endif // !__HYBRID_NODE_H__

