/**
 * Copyright (c) 2017 Seeed Technology Co., Ltd.
 *
 * @author Jack Shao <jacky.shaoxg@gmail.com>
 *
 */

#ifndef __BASE_NODE_H__
#define __BASE_NODE_H__

#include <cstddef>
#include <cstdint>
#include <memory>
#include <list>
#include <unordered_map>
#include <queue>
#include <string>
#include <utility>
#include <thread>
#include <chrono>
#include <functional>
#include <atomic>
#include <mutex>
#include <condition_variable>

#include "chain_nodes/chain_shared.h"

//This is used to validate the parameter of function BindToCore().
#ifndef NUM_CPU_CORE
#define NUM_CPU_CORE 4
#endif

namespace respeaker
{

/** The paramenters for a node's input and output block */
struct NodeParameter
{
    size_t block_len_ms; ///< The time length of the block, in milliseconds
    int rate;            ///< The sample rate
    size_t num_channel;  ///< The number of channels
    bool interleaved;    ///< If or not the audio data is interleaved
};

class BaseNode
{
public:
    BaseNode();
    virtual ~BaseNode() = default;

    /** Get the unique ID of a node */
    BaseNode* GetId();

    /**
     * Link up to the upstream node.
     *
     * @param uplink_node - The pointer of the upstream node.
     */
    void Uplink(BaseNode* uplink_node);

    /**
     * Link down to the downstream node.
     *
     * @param downlink_node - The pointer of the downstream node
     */
    void RegisterDownlinkNode(BaseNode* downlink_node);

    /**
     * Get the output paramenter of this node.
     *
     *
     * @return NodeParameter& - The NodeParamenter struct.
     */
    NodeParameter& GetNodeOutputParameter() { return _output_parameter; }

    /**
     * The `shared_data` must be passed in, typically the `shared_data` is created by the `ReSpeaker` supervisor class.
     *
     * @param shared_data - The pointer of the ChainSharedData struct.
     *
     * @return bool - If `false` is returned , this means that the output paramenter of upstream node doesn't meet the
     *         requirement of a particular node.
     */
    bool RecursivelyStartThread(ChainSharedData* shared_data);

    bool RecursivelyJoinThread();

    /** The derived node must configure the output parameter in this method */
    virtual bool OnStartThread() = 0;

    /**
     * The head node must override this method, to do real audio data fetching
     *
     * @param exit [out] - The exit flag of the ChainSharedData is set, the thread should join now.
     *
     * @return std::string
     */
    virtual std::string FetchBlock(bool& exit);

    /**
     * Every node must implement this method.
     *
     * @param block [in]
     * @param exit [out] - The exit flag of the ChainSharedData is set, the thread should join now.
     *
     * @return std::string
     */
    virtual std::string ProcessBlock(std::string block, bool& exit) = 0;

    /**
     * This method has default implementation, in most times, we can forget this method.
     *
     * @param block [in]
     * @param exit [out] - The exit flag of the ChainSharedData is set, the thread should join now.
     */
    virtual void StoreBlock(std::string block, bool& exit);

    /**
     * Do per node cleanup in this method.
     */
    virtual bool OnJoinThread() = 0;

    virtual void Pause();
    virtual void Resume();

    std::mutex* GetDownlinkDataQueueMutex(BaseNode* downlink_node_id = nullptr);
    std::condition_variable* GetDownlinkDataQueueConditionVar(BaseNode* downlink_node_id = nullptr);
    std::queue<std::string>& GetDownlinkDataQueue(BaseNode* downlink_node_id = nullptr);

    /**
     * Get the average deepth of the output queues.
     * This is supposed to be a debugging method, to see the load of chain.
     */
    int GetQueueDeepth();

    /**
     * Bind the thread to a specified CPU core. Dont touch this method unless you know what's happening
     */
    bool BindToCore(int core_index);

private:
    void _InitBeforeStart();
    void _ThreadProc();

    std::unique_ptr<std::thread> _thread;

    std::unordered_map<BaseNode*, std::unique_ptr<std::mutex>> _map_data_queue_mutexes;
    std::unordered_map<BaseNode*, std::unique_ptr<std::condition_variable>> _map_data_queue_cvs;
    std::unordered_map<BaseNode*, std::queue<std::string>> _map_downlink_data_queues;

    bool _paused;
    int _core_index;
    bool _enable_queue_flush;

protected:
    /** The down-node requests data from up-node, the ownership is: down-node explicitly owns up-node */
    BaseNode* _uplink_node;

    /** The downlink path is only used to do recursive calls */
    std::list<BaseNode*> _list_downlink_nodes;

    NodeParameter _input_parameter;
    NodeParameter _output_parameter;

    ChainSharedData* _chain_shared_data;
    bool _is_head;
    bool _is_tail;

    /**
     * Enable or disable flush the output queue. This method can only be callbed in `ProcessBlock`. If the deepth of queue
     * gets crazy big, this is a disaster, we need to flush the queue anyway to avoid the chain entering unstable.
     */
    void EnableQueueFlush(bool enable);

};

} // namespace respeaker

#endif // !__NODE_BASE_H__
