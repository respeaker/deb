/**
 * Copyright (c) 2017 Seeed Technology Co., Ltd.
 *
 * @author Jack Shao <jacky.shaoxg@gmail.com>
 *
 */



#ifndef __PULSE_COLLECTOR_NODE_H__
#define __PULSE_COLLECTOR_NODE_H__

#include "chain_nodes/base_node.h"

namespace respeaker
{

class PulseCollectorNode : public BaseNode
{
public:
    /**
     * Create a PulseCollectorNode instance.
     *
     * @param source_name - Users can obtain this by `pactl list sources`
     * @param rate
     *
     * @return PulseCollectorNode*
     */
    static PulseCollectorNode* Create(std::string source_name, int rate);

    /**
     * @param source_name
     * @param rate
     * @param block_len_ms - The output block time length, in milliseconds
     *
     * @return PulseCollectorNode*
     */
    static PulseCollectorNode* Create(std::string source_name, int rate, int block_len_ms);

    virtual ~PulseCollectorNode() = default;

    virtual bool OnStartThread() = 0;
    virtual std::string FetchBlock(bool& exit) = 0;
    virtual std::string ProcessBlock(std::string block, bool& exit) = 0;
    virtual bool OnJoinThread() = 0;

    virtual void Pause() = 0;
    virtual void Resume() = 0;
};

}  //namespace

#endif // !__PULSE_COLLECTOR_NODE_H__